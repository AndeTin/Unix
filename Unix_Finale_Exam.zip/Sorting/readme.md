# User Manual

## How to Use the Program

This program sorts a large set of floating-point numbers in parallel using a custom implementation of quicksort and multi-threading. Follow these steps to use the program:

1. **Compile the Program:**
   Use the provided Makefile to compile the program:
   ```bash
   make
   ```

2. **Run the Program:**
   Execute the compiled binary with the following syntax:
   ```bash
   ./parallel_sort <input_file> [num_threads]
   ```

   - `<input_file>`: Path to the file containing the numbers to be sorted. Each number should be on a new line.
   - `[num_threads]` (optional): The number of threads to use for parallel sorting. If not specified, the program defaults to using the number of hardware threads available.

   Example:
   ```bash
   ./parallel_sort data.txt 4
   ```
   This command sorts the numbers in `data.txt` using 4 threads.

3. **Output File:**
   The sorted numbers are written to `output.txt` in the same directory as the program.

## New Multi-Core Configuration

The program now supports user-configurable multi-core processing through an optional command-line argument:

- **Default Behavior:**
  If no number of threads is specified, the program automatically detects and uses the number of hardware threads available on the system.

- **Custom Configuration:**
  Users can specify the number of threads by adding a second argument when running the program. For example:
  ```bash
  ./parallel_sort data.txt 8
  ```
  This command sorts the data using 8 threads.

- **Error Handling:**
  If an invalid number of threads is specified (e.g., a non-integer or a value less than 1), the program will display an error message and terminate.

## Execution Time

After completing the sorting, the program outputs the execution time in seconds to the console, providing insights into performance with different thread configurations.

# Solution Design

## Assumptions

- The input file is well-formed, containing one floating-point number per line.
- The machine running the program supports multi-threading.
- The program's performance scales with the number of threads up to a reasonable limit based on the hardware.

## Algorithms and Parallel Design

- **Sorting Algorithm:**
  The program uses a custom implementation of quicksort for sorting individual chunks of data.

- **Parallel Processing:**
  - The input data is divided into equal-sized chunks, and each chunk is sorted independently using quicksort in separate threads.
  - A parallel merge process combines the sorted chunks iteratively until the entire dataset is merged into a single sorted array.

- **Thread Management:**
  - The number of threads used can be configured at runtime through the command-line argument.
  - Threads are distributed efficiently to handle sorting and merging tasks.

## Output Details

- The sorted numbers are written to `output.txt` in ASCII format with six decimal places.
- The execution time is displayed in seconds to the console.

