#include <iostream>
#include <fstream>
#include <vector>
#include <thread>
#include <chrono>
#include <mutex>
#include <iomanip>
#include <sstream>

std::mutex mtx;

void read_numbers_from_file(const std::string& file_name, std::vector<float>& numbers) {
    std::ifstream input_file(file_name);
    if (!input_file.is_open()) {
        throw std::runtime_error("Unable to open input file");
    }

    float number;
    while (input_file >> number) {
        numbers.push_back(number);
    }
    input_file.close();
}

void write_numbers_to_file(const std::string& file_name, const std::vector<float>& numbers) {
    std::ofstream output_file(file_name);
    if (!output_file.is_open()) {
        throw std::runtime_error("Unable to open output file");
    }

    for (const auto& number : numbers) {
        output_file << std::fixed << std::setprecision(6) << number << "\n";
    }
    output_file.close();
}

void custom_quicksort(std::vector<float>& numbers, size_t left, size_t right) {
    if (left >= right) {
        return;
    }

    float pivot = numbers[right];
    size_t i = left;

    for (size_t j = left; j < right; ++j) {
        if (numbers[j] < pivot) {
            std::swap(numbers[i], numbers[j]);
            ++i;
        }
    }
    std::swap(numbers[i], numbers[right]);

    if (i > 0) custom_quicksort(numbers, left, i - 1);
    custom_quicksort(numbers, i + 1, right);
}

void parallel_sort_chunk(std::vector<float>& numbers, size_t start, size_t end) {
    custom_quicksort(numbers, start, end - 1);
}

void merge_chunks(std::vector<float>& numbers, size_t start1, size_t end1, size_t start2, size_t end2, std::vector<float>& temp) {
    size_t i = start1, j = start2, k = start1;
    while (i < end1 && j < end2) {
        if (numbers[i] <= numbers[j]) {
            temp[k++] = numbers[i++];
        } else {
            temp[k++] = numbers[j++];
        }
    }
    while (i < end1) temp[k++] = numbers[i++];
    while (j < end2) temp[k++] = numbers[j++];

    for (size_t m = start1; m < end2; ++m) {
        numbers[m] = temp[m];
    }
}

void parallel_merge(std::vector<float>& numbers, size_t step, std::vector<float>& temp, size_t num_threads) {
    std::vector<std::thread> threads;

    for (size_t i = 0; i < num_threads; i += 2) {
        size_t start1 = i * step;
        size_t end1 = std::min(start1 + step, numbers.size());
        size_t start2 = end1;
        size_t end2 = std::min(start2 + step, numbers.size());

        if (start2 < numbers.size()) {
            threads.emplace_back(merge_chunks, std::ref(numbers), start1, end1, start2, end2, std::ref(temp));
        }
    }

    for (auto& t : threads) {
        t.join();
    }
}

int main(int argc, char* argv[]) {
    if (argc < 2 || argc > 3) {
        std::cerr << "Usage: " << argv[0] << " <input_file> [num_threads]" << std::endl;
        return 1;
    }

    const std::string input_file = argv[1];
    const std::string output_file = "output.txt";
    size_t num_threads = std::thread::hardware_concurrency();

    if (argc == 3) {
        std::istringstream ss(argv[2]);
        if (!(ss >> num_threads) || num_threads < 1) {
            std::cerr << "Invalid number of threads specified." << std::endl;
            return 1;
        }
    }

    std::vector<float> numbers;

    try {
        auto start_time = std::chrono::high_resolution_clock::now();

        // Read input
        read_numbers_from_file(input_file, numbers);
        size_t chunk_size = (numbers.size() + num_threads - 1) / num_threads;

        // Parallel sort
        std::vector<std::thread> threads;
        for (size_t i = 0; i < num_threads; ++i) {
            size_t start = i * chunk_size;
            size_t end = std::min(start + chunk_size, numbers.size());
            threads.emplace_back(parallel_sort_chunk, std::ref(numbers), start, end);
        }

        for (auto& t : threads) {
            t.join();
        }

        // Prepare for merging
        std::vector<float> temp(numbers.size());
        size_t step = chunk_size;

        // Merge chunks in parallel
        while (step < numbers.size()) {
            parallel_merge(numbers, step, temp, num_threads);
            step *= 2;
        }

        auto end_time = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed_time = end_time - start_time;

        // Write output
        write_numbers_to_file(output_file, numbers);

        std::cout << "Sorting completed. Output written to " << output_file << std::endl;
        std::cout << "Execution time: " << elapsed_time.count() << " seconds" << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
